
<div class="load-more-container">
        <button id="load-more-button" data-type="<?php echo $args['custom_post_types']; ?>" class="btn"><?php _e("Load More", "load-more"); ?></button>
    </div,$args['key']