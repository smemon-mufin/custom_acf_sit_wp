<form action="<?php echo get_bloginfo('siteurl'); ?>">
    <div class="search-input">
        <input name="s" type="text" placeholder="Search" autocomplete="off">
        <button type="submit"><?php echo getSVG('search'); ?></button>
    </div>
</form>