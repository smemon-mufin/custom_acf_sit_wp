jQuery(document).ready(function ($) {
    var AdminScripts = (function () {
        if (!$('.wp-admin')) return;

    }());
});